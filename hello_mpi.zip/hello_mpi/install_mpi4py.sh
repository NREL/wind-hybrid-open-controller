ml mamba
mamba create -n hello_mpi \
  conda-forge::pip \
  conda-forge::pandas \
  conda-forge::numpy \
  conda-forge::python=3.11 \
  --yes

conda activate hello_mpi
MPICC="cc -shared" pip install --force-reinstall --no-cache-dir --no-binary=mpi4py mpi4py