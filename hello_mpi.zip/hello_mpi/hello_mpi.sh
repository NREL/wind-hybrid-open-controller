#!/bin/bash
#SBATCH -A <your_account>
#SBATCH -p debug
#SBATCH -t 00:10:00
#SBATCH -N 2
#SBATCH --job-name="hello_mpi"
#SBATCH -o %x-%j.out

ml restore system
ml mamba
conda activate hello_mpi

export MAXWORKERS=`echo $(($SLURM_CPUS_ON_NODE * $SLURM_JOB_NUM_NODES))`
srun -n $MAXWORKERS python hello_mpi.py

